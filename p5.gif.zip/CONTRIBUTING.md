Hi there! Welcome to p5.gif contributing! Here are a few things to know:

The github issues are for bugs and feature requests for the p5.gif library itself and some general questions could be asked via [p5.js forum](https://forum.processing.org/two/).

Please be polit, patient and creative and that is waht we want.

We have made templates for issues and pull request. Please be sure to follow them. If you have any further questions, we are wellcome to start a new issue on it.

We are using [git-emoji-commit](https://gitmoji.carloscuesta.me/) style. Be sure to follow that. 

(This CONTRIBUTING is adapted from [p5js CONTRIBUTING](https://github.com/processing/p5.js/blob/master/CONTRIBUTING.md) Great thanks to them)
